#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){	
    ofBackground(0); //背景を黒にする
    
    mFbo.allocate(ofGetWidth(), ofGetHeight()); //保持する画像の大きさを設定
    
    //guiの設定
    gui.setup("setting");
    gui.add(colorSlider.setup("color", ofColor(200,200,100),0, 255));
    gui.add(circleSizeSlider.setup("circleSize", 10, 1, 200));
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
    mFbo.begin();
    
    ofSetColor(colorSlider);
    for (int finID = 0; finID < FIN_NUM; finID++) { //指の数だけループ
        
        if (isTouching[finID]) { //指がタッチしていたら円を描画する
            ofEllipse(touchedPos[finID], circleSizeSlider, circleSizeSlider);
        }
        
    }
    
    mFbo.end();
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    ofSetColor(255);
    mFbo.draw(0, 0);
    
    ofDrawBitmapString(ofToString(ofGetFrameRate()), 10, 500); //フレームレートをテキストで描画　ofToStringでofGetFrameRateで取得したフレームレートの値をstring型に変換している
    
    gui.draw();
    
}

//--------------------------------------------------------------
void ofApp::exit(){

}

//--------------------------------------------------------------
void ofApp::touchDown(ofTouchEventArgs & touch){ //タッチした時に呼ばれる
    touchedPos[touch.id] = ofPoint(touch.x, touch.y); //touch.x touch.yはそれぞれint型の変数　touchedPosがofPoint型なのでそれにあわせるためにこういう書き方になる
    isTouching[touch.id] = true;
}

//--------------------------------------------------------------
void ofApp::touchMoved(ofTouchEventArgs & touch){ //タッチして指を動かした時に呼ばれる
    touchedPos[touch.id] = ofPoint(touch.x, touch.y);
}

//--------------------------------------------------------------
void ofApp::touchUp(ofTouchEventArgs & touch){ //タッチして指を画面からはなした時に呼ばれる
    isTouching[touch.id] = false;
}

//--------------------------------------------------------------
void ofApp::touchDoubleTap(ofTouchEventArgs & touch){ //ダブルタッチした時に呼ばれる

}

//--------------------------------------------------------------
void ofApp::touchCancelled(ofTouchEventArgs & touch){
    
}

//--------------------------------------------------------------
void ofApp::lostFocus(){

}

//--------------------------------------------------------------
void ofApp::gotFocus(){

}

//--------------------------------------------------------------
void ofApp::gotMemoryWarning(){

}

//--------------------------------------------------------------
void ofApp::deviceOrientationChanged(int newOrientation){

}
